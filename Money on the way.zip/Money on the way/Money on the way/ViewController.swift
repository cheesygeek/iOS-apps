//
//  ViewController.swift
//  Money on the way
//
//  Created by Patrick Benie on 31/05/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

